<?php
require 'config.php';
if(empty($_SESSION['user'])){
    header('Location: login.php?redirect=checkout.php'); exit;
}
$cart = $_SESSION['cart'] ?? [];
if(empty($cart)){ header('Location: cart.php'); exit; }
$total = 0; foreach($cart as $it) $total += $it['price']*$it['qty'];

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $user_id = $_SESSION['user']['id'];
    $mysqli->begin_transaction();
    try {
        $stmt = $mysqli->prepare("INSERT INTO orders (user_id,total) VALUES (?,?)");
        $stmt->bind_param('id',$user_id,$total); $stmt->execute();
        $order_id = $mysqli->insert_id;
        $stmt2 = $mysqli->prepare("INSERT INTO order_items (order_id,product_id,qty,price) VALUES (?,?,?,?)");
        foreach($cart as $it){
            $stmt2->bind_param('iiid',$order_id,$it['id'],$it['qty'],$it['price']);
            $stmt2->execute();
            // reduce stock
            $u = $mysqli->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
            $u->bind_param('ii',$it['qty'],$it['id']); $u->execute();
        }
        $mysqli->commit();
        unset($_SESSION['cart']);
        $success = true;
    } catch(Exception $e){
        $mysqli->rollback();
        $error = $e->getMessage();
    }
}
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Checkout</title>
		<link rel="stylesheet" href="style.css">
	</head>
	<body>
<header class="site-header"><a class="brand" href="index.php">Qina's Store</a></header>
<main class="container">
  <h1>Checkout</h1>
  <?php if(!empty($success)): ?>
    <div class="notice">Order placed! Thank you.</div>
    <a class="btn" href="index.php">Continue Shopping</a>
  <?php else: ?>
    <p>Total to pay: <strong>RM <?=number_format($total,2)?></strong></p>
    <form method="post">
      <p>Payment method:  Cash on Delivery</p>
      <button class="btn primary">Place Order</button>
    </form>
    <?php if(!empty($error)): ?><p class="error"><?=e($error)?></p><?php endif; ?>
  <?php endif; ?>
</main>
</body>
</html>