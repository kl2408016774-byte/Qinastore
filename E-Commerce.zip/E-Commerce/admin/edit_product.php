<?php
require '../config.php';

// Only admin
if (empty($_SESSION['user']) || !$_SESSION['user']['is_admin']) {
    header('Location: login.php');
    exit;
}

$id = intval($_GET['id'] ?? 0);

// Get product details
$stmt = $mysqli->prepare("SELECT * FROM products WHERE id=?");
$stmt->bind_param('i', $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    header("Location: products.php");
    exit;
}

// Update product when POSTed
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = $_POST['name'];
    $desc = $_POST['description'];
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    $image = $product['image'];

    // If new image uploaded
    if (!empty($_FILES['image']['name'])) {
        $filename = basename($_FILES['image']['name']);
        $target = "../uploads/" . $filename;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $image = "uploads/" . $filename;
        }
    }

    $stmt = $mysqli->prepare("
        UPDATE products 
        SET name=?, description=?, price=?, stock=?, image=? 
        WHERE id=?
    ");

    $stmt->bind_param('ssdisi', $name, $desc, $price, $stock, $image, $id);
    $stmt->execute();

    header("Location: products.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<header class="site-header">
    <a class="brand" href="dashboard.php">Admin Panel</a>
    <nav>
        <a href="products.php">Back</a>
        <a href="../logout.php">Logout</a>
    </nav>
</header>

<main class="container">
    <h1>Edit Product</h1>

    <form method="post" enctype="multipart/form-data">
        <label>Name</label>
        <input name="name" value="<?= htmlspecialchars($product['name']) ?>">

        <label>Description</label>
        <textarea name="description"><?= htmlspecialchars($product['description']) ?></textarea>

        <label>Price (RM)</label>
        <input name="price" type="number" step="0.01" value="<?= $product['price'] ?>">

        <label>Stock</label>
        <input name="stock" type="number" value="<?= $product['stock'] ?>">

        <label>Image</label>
        <img src="../<?= $product['image'] ?>" width="120" style="border-radius:10px;margin-bottom:10px;">
        <input type="file" name="image">

        <button class="btn primary">Update Product</button>
    </form>
</main>

</body>
</html>
