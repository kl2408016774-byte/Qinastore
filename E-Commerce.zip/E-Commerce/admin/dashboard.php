<?php
require '../config.php';

// Only admin can access
if (!isset($_SESSION['user']) || !$_SESSION['user']['is_admin']) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<header class="site-header">
    <a class="brand" href="dashboard.php/dashboard.php">Admin Panel - Qina Store</a>
    <nav>
        <a href="dashboard.php/products.php">Manage Products</a>
       
        <a href="logout.php">Logout</a>
    </nav>
</header>

<main class="admin-dashboard">

    <div class="dashboard-welcome">
        <h2 class="admin-title">Welcome, Admin!</h2>
        <p>You can manage products and view store overview here.</p>
    </div>

    <div class="stat-boxes">
        <div class="stat">
            <h2>12</h2>
            <span>Total Products</span>
        </div>

        <div class="stat">
            <h2>5</h2>
            <span>New Orders</span>
        </div>

        <div class="stat">
            <h2>3</h2>
            <span>Pending</span>
        </div>
    </div>

    <h2 style="margin-top:30px;">Quick Actions</h2>

    <div class="dashboard-grid">

        <div class="dashboard-card">
            <h3>Manage Products</h3>
            <p>Edit, delete and add new items to your store.</p>
            <div class="dashboard-buttons">
                <a href="products.php" class="btn primary">Open</a>
            </div>
        </div>

        <div class="dashboard-card">
            <h3>Add New Product</h3>
            <p>Insert a new item with image, price, and stock.</p>
            <div class="dashboard-buttons">
                <a href="add_product.php" class="btn">Add</a>
            </div>
        </div>

    </div>

</main>

</body>
</html>
