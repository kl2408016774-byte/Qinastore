<?php
require '../config.php';
if(empty($_SESSION['user']) || !$_SESSION['user']['is_admin']) { header('Location: login.php'); exit; }
$res = $mysqli->query("SELECT * FROM products ORDER BY id DESC");
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Products</title>
		<link rel="stylesheet" href="../style.css">
	</head>
<body>
	<main class="container">
		<h1>Products</h1>
		<a class="btn" href="add_product.php">Add Product</a>
<table class="admin-table">
	<thead>
		<tr><th>ID</th>
			<th>Name</th>
			<th>Price</th>
			<th>Stock</th>
			<th>Actions</th>
		</tr>
	</thead>
	<tbody>
<?php while($p=$res->fetch_assoc()): ?>
<tr>
  <td><?=$p['id']?></td>
  <td><?=e($p['name'])?></td>
  <td>RM <?=number_format($p['price'],2)?></td>
  <td><?=$p['stock']?></td>
  <td>
    <a class="btn" href="edit_product.php?id=<?=$p['id']?>">Edit</a>
    <a class="btn secondary" href="delete_product.php?id=<?=$p['id']?>" onclick="return confirm('Delete?')">Delete</a>
  </td>
</tr>
<?php endwhile; ?>
</tbody>
		</table>
</main>
	</body>
</html>