<?php
session_start();
require '../config.php';

// Pastikan admin login
if (empty($_SESSION['user']) || !$_SESSION['user']['is_admin']) {
    header('Location: login.php');
    exit;
}

// Check kalau ada ID product
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // pastikan integer

    // Prepare delete
    $stmt = $mysqli->prepare("DELETE FROM products WHERE id = ?");
    if (!$stmt) {
        die("Prepare failed: " . $mysqli->error);
    }

    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: dashboard.php?msg=Product deleted successfully");
        exit;
    } else {
        echo "Error deleting product: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "No product ID provided.";
}

$mysqli->close();
?>
