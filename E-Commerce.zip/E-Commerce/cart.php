<?php
require 'config.php';
$action = $_REQUEST['action'] ?? null;

if($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST'){
    $pid = intval($_POST['product_id']);
    $qty = max(1,intval($_POST['qty'] ?? 1));
    // fetch product info
    $stmt = $mysqli->prepare("SELECT id,name,price,stock,image FROM products WHERE id=?");
    $stmt->bind_param('i',$pid); $stmt->execute();
    $prod = $stmt->get_result()->fetch_assoc();
    if($prod){
        if(!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
        if(isset($_SESSION['cart'][$pid])){
            $_SESSION['cart'][$pid]['qty'] += $qty;
        } else {
            $_SESSION['cart'][$pid] = ['id'=>$prod['id'],'name'=>$prod['name'],'price'=>$prod['price'],'qty'=>$qty,'image'=>$prod['image']];
        }
    }
    header('Location: cart.php'); exit;
}

if($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST'){
    foreach($_POST['qty'] as $pid=>$q){
        $pid = intval($pid);
        $q = max(0,intval($q));
        if($q === 0){ unset($_SESSION['cart'][$pid]); continue; }
        if(isset($_SESSION['cart'][$pid])) $_SESSION['cart'][$pid]['qty']=$q;
    }
    header('Location: cart.php'); exit;
}

if($action === 'clear'){
    unset($_SESSION['cart']);
    header('Location: cart.php'); exit;
}

$cart = $_SESSION['cart'] ?? [];
$total = 0;
foreach($cart as $item) $total += $item['price'] * $item['qty'];
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Cart</title>
		<link rel="stylesheet" href="style.css">
	</head>
<body>
<header class="site-header">
	<a class="brand" href="index.php">Qina's Store</a>
	</header>
<main class="container">
  <h1>Your Cart</h1>
  <?php if(empty($cart)): ?>
    <p>Your cart is empty. <a href="index.php">Continue shopping</a></p>
  <?php else: ?>
    <form method="post" action="cart.php?action=update">
      <table class="cart-table">
        <thead>
			<tr>
				<th>Product</th>
				<th>Price</th>
				<th>Qty</th>
				<th>Subtotal</th>
			</tr>
		  </thead>
        <tbody>
        <?php foreach($cart as $id=>$it): ?>
          <tr>
            <td><?=e($it['name'])?></td>
            <td>RM <?=number_format($it['price'],2)?></td>
            <td><input type="number" name="qty[<?=$id?>]" value="<?=e($it['qty'])?>" min="0" style="width:70px"></td>
            <td>RM <?=number_format($it['price']*$it['qty'],2)?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <p class="total">Total: RM <?=number_format($total,2)?></p>
      <button class="btn">Update Cart</button>
      <a class="btn secondary" href="cart.php?action=clear">Clear</a>
      <a class="btn primary" href="checkout.php">Checkout</a>
    </form>
  <?php endif; ?>
</main>
</body>
</html>