<?php require 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us - Qina’s Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header class="site-header">
    <a class="brand" href="admin/index.php">Qina’s Store</a>
    <nav>
        <a href="index.php">Home</a>
        <a href="about.php">About Us</a>
        <a href="cart.php">Cart</a>
    </nav>
</header>

<main class="container about-wrapper">

    <section class="about-card">
        <h1>About Qina’s Store</h1>
        <p>
            Welcome to <strong>Qina’s Store</strong>, an elegant mini e-commerce platform 
            built to provide a simple, clean and user-friendly shopping experience.
            
        </p>
		<p>
			Since the beginning, our goal has been to provide a clean, user-friendly, and enjoyable shopping experience for everyone.
			At Qina’s Store, every product is carefully selected to ensure value, quality, and satisfaction.
		</p>
		<p>
			🌐 Find Us on Social Media</p>
			
		<p>Stay connected with us for updates, promotions, and new product releases</p>
			
		<p>Facebook: facebook.com/qinasstore</p>
		<p>Instagram: instagram.com/qinasstore</p>
		<p>TikTok: tiktok.com/@qinasstore</p>
		<p>Email: support@qinasstore.com</p>
			<p>Phone: +60 12-345 6789</p>
        <p>
            Thank you for visiting and exploring this project! 💗
        </p>

    </section>

</main>

<footer class="site-footer">
    © <?= date("Y") ?> Qina’s Store. All Rights Reserved.
</footer>

</body>
</html>
