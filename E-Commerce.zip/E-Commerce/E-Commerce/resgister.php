<?php
require 'config.php';
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name = $_POST['name']; $email = $_POST['email']; $pass = $_POST['password'];
  if($name && $email && $pass){
    $hash = hash('sha256',$pass);
    $stmt = $mysqli->prepare("INSERT INTO users (name,email,password) VALUES (?,?,?)");
    $stmt->bind_param('sss',$name,$email,$hash);
    if($stmt->execute()){
      header('Location: login.php'); exit;
    } else { $msg = "Registration failed or email used."; }
  } else $msg='Please fill all fields.';
}
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Register</title>
		<link rel="stylesheet" href="style.css">
	</head>
<body>
<header class="site-header"><a class="brand" href="index.php">Qina's Store</a></header>
<main class="container">
  <h1>Register</h1>
  <?php if($msg) echo "<p class='error'>".e($msg)."</p>"; ?>
  <form method="post">
    <label>Name <input name="name" required></label>
    <label>Email <input name="email" type="email" required></label>
    <label>Password <input name="password" type="password" required></label>
    <button class="btn">Register</button>
  </form>
</main>
</body>
</html>