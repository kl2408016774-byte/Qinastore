<?php
require 'config.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $mysqli->prepare("SELECT * FROM products WHERE id=?");
$stmt->bind_param('i',$id);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();
if(!$p){ header('Location: index.php'); exit; }
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title><?=e($p['name'])?></title><link rel="stylesheet" href="style.css"></head>
<body>
    <div class="info">
      <h2><?=e($p['name'])?></h2>
      <p class="price">RM <?=number_format($p['price'],2)?></p>
      <p><?=nl2br(e($p['description']))?></p>
      <p>Stock: <?=e($p['stock'])?></p>
      <form method="post" action="cart.php">
        <input type="hidden" name="product_id" value="<?=$p['id']?>">
        <input type="hidden" name="action" value="add">
        <label>Qty <input type="number" name="qty" value="1" min="1" max="<?=e($p['stock'])?>"></label>
        <button class="btn">Add to Cart</button>
      </form>
    </div>
  </div>
</main>
</body>
</html>
