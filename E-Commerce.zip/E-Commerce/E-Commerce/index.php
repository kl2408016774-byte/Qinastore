<?php
require 'config.php';
$search = $_GET['q'] ?? '';
$stmt = $mysqli->prepare("SELECT id,name,price,stock,image FROM products WHERE name LIKE CONCAT('%',?,'%') ORDER BY created_at DESC");
$stmt->bind_param('s',$search);
$stmt->execute();
$res = $stmt->get_result();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Qina's Store</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="site-header">
  <a class="brand" href="index.php">Qina's Store</a>
  <nav>
    <form method="get" class="search">
      <input name="q" placeholder="Search products..." value="<?=e($search)?>">
      <button type="submit">Search</button>
    </form>
    <a href="cart.php">Cart (<?= isset($_SESSION['cart'])?array_sum(array_column($_SESSION['cart'],'qty')):0 ?>)</a>
    <?php if(isset($_SESSION['user'])): ?>
      <span><?=e($_SESSION['user']['name'])?></span> | <a href="logout.php">Logout</a>
      <?php if($_SESSION['user']['is_admin']): ?><a href="admin/dashboard.php">Admin</a><?php endif; ?>
    <?php else: ?>
      <a href="login.php">Login</a> | <a href="register.php">Register</a>
    <?php endif; ?>
  </nav>
</header>

<main class="container">
  <h1>Products</h1>
  <div class="grid">
    <?php while($p = $res->fetch_assoc()): ?>
      <div class="card">
        <img src="<?=e($p['image'])?>" alt="<?=e($p['name'])?>">
        <h3><?=e($p['name'])?></h3>
        <p class="price">RM <?=number_format($p['price'],2)?></p>
        <p>Stock: <?=e($p['stock'])?></p>
        <div class="actions">
          <a class="btn" href="product.php?id=<?=$p['id']?>">View</a>
          <form method="post" action="cart.php" style="display:inline">
            <input type="hidden" name="product_id" value="<?=$p['id']?>">
            <input type="hidden" name="action" value="add">
            <input type="number" name="qty" value="1" min="1" max="<?=e($p['stock'])?>" style="width:60px">
            <button class="btn secondary">Add</button>
          </form>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
</main>
<footer class="site-footer">© <?=date('Y')?> Qina's Store</footer>
</body>
</html>