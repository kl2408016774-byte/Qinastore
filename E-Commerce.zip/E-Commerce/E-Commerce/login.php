<?php
require 'config.php';
$msg='';
$redirect = $_GET['redirect'] ?? 'index.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $email = $_POST['email']; $pass = $_POST['password'];
  $hash = hash('sha256',$pass);
  $stmt = $mysqli->prepare("SELECT id,name,email,is_admin FROM users WHERE email=? AND password=? LIMIT 1");
  $stmt->bind_param('ss',$email,$hash); $stmt->execute();
  $user = $stmt->get_result()->fetch_assoc();
  if($user){
    $_SESSION['user'] = $user;
    header("Location: $redirect"); exit;
  } else $msg = 'Invalid credentials';
}
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Login</title>
		<link rel="stylesheet" href="style.css">
	</head>
<body>
<header class="site-header"><a class="brand" href="index.php">Qina's Store</a></header>
<main class="container">
  <h1>Login</h1>
  <?php if($msg) echo "<p class='error'>".e($msg)."</p>"; ?>
  <form method="post">
    <label>Email <input name="email" type="email" required></label>
    <label>Password <input name="password" type="password" required></label>
    <button class="btn">Login</button>
  </form>
</main>
</body>
</html>