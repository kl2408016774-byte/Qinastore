<?php
require '../config.php';
if(empty($_SESSION['user']) || !$_SESSION['user']['is_admin']) { header('Location: login.php'); exit; }
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name=$_POST['name']; $desc=$_POST['description']; $price=floatval($_POST['price']); $stock=intval($_POST['stock']);
  // simple image upload (optional)
  $image = 'uploads/default.png';
  if(!empty($_FILES['image']['name'])){
    $t = $_FILES['image'];
    $target = '../uploads/'.basename($t['name']);
    move_uploaded_file($t['tmp_name'],$target);
    $image = 'uploads/'.basename($t['name']);
  }
  $stmt = $mysqli->prepare("INSERT INTO products (name,description,price,stock,image) VALUES (?,?,?,?,?)");
  $stmt->bind_param('ssdiss',$name,$desc,$price,$stock,$image); // note: binding types adjusted
  if($stmt->execute()){ header('Location: products.php'); exit; } else $msg='Error saving';
}
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Add</title>
		<link rel="stylesheet" href="../style.css">
	</head>
<body>
	<main class="container">
		<h1>Add Product</h1>
		<?php if($msg) echo "<p class='error'>".e($msg)."</p>"; ?>
<form method="post" enctype="multipart/form-data">
<label>Name <input name="name" required></label>
<label>Price <input name="price" type="number" step="0.01" required></label>
<label>Stock <input name="stock" type="number" required></label>
<label>Description <textarea name="description"></textarea></label>
<label>Image <input type="file" name="image" accept="image/*"></label>
<button class="btn">Save</button>
</form>
	</main>
	</body>
</html>